package edu.wustl.honeyrj.lowinteraction;

public class LIModuleException extends Exception {

	private static final long serialVersionUID = -5603003753744385996L;

	public LIModuleException(String string) {
		super(string);
	}

}
