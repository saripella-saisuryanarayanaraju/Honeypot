package edu.wustl.honeyrj.logging;

public class LoggingException extends Exception {

	public LoggingException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 8020025770219336330L;

}
