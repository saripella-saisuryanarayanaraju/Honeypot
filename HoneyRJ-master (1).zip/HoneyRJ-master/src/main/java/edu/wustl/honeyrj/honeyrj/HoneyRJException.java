package edu.wustl.honeyrj.honeyrj;

public class HoneyRJException extends Exception {

	private static final long serialVersionUID = 8385429208599826050L;

	public HoneyRJException(String string) {
		super(string);
	}

}
