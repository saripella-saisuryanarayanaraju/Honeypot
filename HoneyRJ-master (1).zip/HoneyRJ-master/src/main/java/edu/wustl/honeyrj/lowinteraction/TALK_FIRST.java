package edu.wustl.honeyrj.lowinteraction;
/**
 * this defines if the server sends the first message in the protocol (FIRST) or if the client does (SECOND)
 * @author Eric Peter
 *
 */
public enum TALK_FIRST {SVR_FIRST, CLIENT_FIRST}
